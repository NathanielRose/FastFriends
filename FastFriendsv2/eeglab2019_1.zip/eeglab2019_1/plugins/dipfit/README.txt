v3.3
- Ensures backward compatiblity with old versions of EEGLAB

v3.2
- Fix bug with missing folders

v3.1
- Improved support for eeglab2fieldtrip.m

v3.0
- Adding support for eLoreta

For documentation see https://sccn.ucsd.edu/wiki/A08:_DIPFIT


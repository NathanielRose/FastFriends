function res = isstruct(this);

    res = 1;
